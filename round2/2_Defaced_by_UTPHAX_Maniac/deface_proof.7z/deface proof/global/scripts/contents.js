$(document).ready(function(){
	
	/*	$("#header .blue").append('<div class="bg_box_top"><img src="/global/images/bg_box_blue_top.png" alt="" width="190" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box_blue_btm.png" alt="" width="190" height="5" /></div>');
	$("#footer .gray").append('<div class="bg_box_top"><img src="/global/images/bg_box_gray_top.png" alt="" width="190" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box_gray_btm.png" alt="" width="190" height="5" /></div>');
	$("#footer .darkgray").append('<div class="bg_box_top"><img src="/global/images/bg_box_darkgray_top.png" alt="" width="190" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box_darkgray_btm.png" alt="" width="190" height="5" /></div>');
	$(".col1.yellow").append('<div class="bg_box_top"><img src="/global/images/bg_box1_yellow_top.png" alt="" width="190" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box1_yellow_btm.png" alt="" width="190" height="5" /></div>');
	$(".col2.yellow").append('<div class="bg_box_top"><img src="/global/images/bg_box2_yellow_top.png" alt="" width="387" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box2_yellow_btm.png" alt="" width="387" height="5" /></div>');
	$(".col3.yellow").append('<div class="bg_box_top"><img src="/global/images/bg_box3_yellow_top.png" alt="" width="584" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box3_yellow_btm.png" alt="" width="584" height="5" /></div>');
	$(".col4.yellow").append('<div class="bg_box_top"><img src="/global/images/bg_box4_yellow_top.png" alt="" width="781" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box4_yellow_btm.png" alt="" width="781" height="5" /></div>');
	$(".col1.aqua").append('<div class="bg_box_top"><img src="/global/images/bg_box1_aqua_top.png" alt="" width="190" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box1_aqua_btm.png" alt="" width="190" height="5" /></div>');
	$(".col2.aqua").append('<div class="bg_box_top"><img src="/global/images/bg_box2_aqua_top.png" alt="" width="387" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box2_aqua_btm.png" alt="" width="387" height="5" /></div>');
	$(".col3.aqua").append('<div class="bg_box_top"><img src="/global/images/bg_box3_aqua_top.png" alt="" width="584" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box3_aqua_btm.png" alt="" width="584" height="5" /></div>');
	$(".col4.aqua").append('<div class="bg_box_top"><img src="/global/images/bg_box4_aqua_top.png" alt="" width="781" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box4_aqua_btm.png" alt="" width="781" height="5" /></div>');
	$(".bdBlue1").append('<div class="bg_box_top"><img src="/global/images/bg_box1_bdblue_top.png" alt="" width="190" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box1_bdblue_btm.png" alt="" width="190" height="5" /></div>');
	$(".bdBlue2").append('<div class="bg_box_top"><img src="/global/images/bg_box2_bdblue_top.png" alt="" width="387" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box2_bdblue_btm.png" alt="" width="387" height="5" /></div>');
	$(".bdBlue3").append('<div class="bg_box_top"><img src="/global/images/bg_box3_bdblue_top.png" alt="" width="584" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box3_bdblue_btm.png" alt="" width="584" height="5" /></div>');
	$(".bdBlue4").append('<div class="bg_box_top"><img src="/global/images/bg_box4_bdblue_top.png" alt="" width="781" height="5" /></div><div class="bg_box_btm"><img src="/global/images/bg_box4_bdblue_btm.png" alt="" width="781" height="5" /></div>');*/

	
	jQuery(function() {
	var topBtn = jQuery('#btn_pagetop');	
	topBtn.hide();
	jQuery(window).scroll(function () {
		if (jQuery(this).scrollTop() > 590) {
			topBtn.fadeIn();
		} else {
			topBtn.fadeOut();
		}
	});
	//�X�N���[�����ăg�b�v�ɖ߂�
	//500�̐�����傫������ƃX�N���[�����x���x���Ȃ�
    topBtn.click(function () {
		jQuery('body,html').animate({
			scrollTop: 0
		}, 500);
		return false;
    });
});

	
	
	setWidth();
	//setHeight();
	
	
	$(window).resize(function() {
		setWidth();
		
	});
	
	function setWidth() {
		var width = $(window).width();
		if (width > 998) {
			$("#container_top").css("width",width - 230 + "px");
		} else {
			$("#container_top").css("width","791px");
		};
	};
	
	/*function setHeight() {
		var height = $("#header").height();
		var myHeight = $("#container_top").height();
		if (myHeight < height) {
			$("#container_top").css("height",height);
		}
		
	}; */
	
	$(".checkbox").change(function(){
		if($(this).is(":checked")){
			$(this).next("label").addClass("LabelSelected");
		}else{
			$(this).next("label").removeClass("LabelSelected");
		}
	});
	
	$("#sel_artist .like_pd").click(function(){
		$("#box_sel").slideToggle("fast");
		$('.jScrollbar').jScrollbar();
	});

	$("#newest .like_pd").click(function(){
		$("#box_sel2").slideToggle("fast");
		$('.jScrollbar2').jScrollbar();
	});

	
	$(".boxLink.gray").hover(function() {
		$(this).stop().animate({ backgroundColor: "#969696"}, 800);
		$(this).find(".bg_box_top").stop().animate({'opacity' : '0'}, 100);
		$(this).find(".bg_box_btm").stop().animate({'opacity' : '0'}, 100);
	},function() {
		$(this).stop().animate({ backgroundColor: "#D2D2D2" }, 800);
		$(this).find(".bg_box_top").stop().animate({'opacity' : '0'}, 5000);
		$(this).find(".bg_box_btm").stop().animate({'opacity' : '0'}, 5000);
	});
	
	/*$(".boxLink.aqua").hover(function() {
		$(this).stop().animate({ backgroundColor: "#19a0e6",color: "#FFFFFF"}, 800);
		$(this).find("a").stop().animate({ color: "#FFFFFF"}, 800);
		$(this).find("h3").stop().animate({ color: "#FFFFFF"}, 800);
		$(this).find(".bg_box_top").stop().animate({'opacity' : '0'}, 100);
		$(this).find(".bg_box_btm").stop().animate({'opacity' : '0'}, 100);
	},function() {
		$(this).stop().animate({ backgroundColor: "#dcf0fa",color: "#474747" }, 800);
		$(this).find("a").stop().animate({ color: "#474747"}, 800);
		$(this).find("h3").stop().animate({ color: "#474747"}, 800);
		$(this).find(".bg_box_top").stop().animate({'opacity' : '0'}, 5000);
		$(this).find(".bg_box_btm").stop().animate({'opacity' : '0'}, 5000);
	});
	
$("#btn_pagetop a").hover(function() {
		$(this).stop().animate({ backgroundColor: "#FFFF00" }, 800);
	},function() {
		$(this).stop().animate({ backgroundColor: "#19a0e6" }, 800);
	});*/
	
	
	
	$(".songTrigger").toggle(
	function() {
		$(this).css("background-image","url(/artist/images/btn_close.png)");
		var __this=$(this).parents(".grid");
		var __h=__this.outerHeight();
		var __l=__this.position().left;
		var __t=__this.position().top;
		$(this).prev().slideToggle('',function(){
			$(".grid").each(function(){
				var boxPos=$(this).position();
				if(__l==boxPos.left&&__t<boxPos.top){
					$(this).animate({"top":__this.outerHeight()-__h+boxPos.top},250);
				}
			});
		});
		$(this).parents(".grid").css("z-index","50");
	},
	function() {
		$(this).css("background-image","url(/artist/images/btn_song_list.png)");
		var __this=$(this).parents(".grid");
		var __h=__this.outerHeight();
		var __l=__this.position().left;
		var __t=__this.position().top;
		$(this).prev().slideToggle('',function(){
			$(".grid").each(function(){
				var boxPos=$(this).position();
				if(__l==boxPos.left&&__t<boxPos.top){
					$(this).animate({"top":__this.outerHeight()-__h+boxPos.top},750);
				}
			});
		});
		$(this).parents(".grid").css("z-index","1");
	});
	
	
	$(".songTriggerEng").toggle(
	function() {
		$(this).css("background-image","url(/artist/images_en/btn_close.png)");
		var __this=$(this).parents(".grid");
		var __h=__this.outerHeight();
		var __l=__this.position().left;
		var __t=__this.position().top;
		$(this).prev().slideToggle('',function(){
			$(".grid").each(function(){
				var boxPos=$(this).position();
				if(__l==boxPos.left&&__t<boxPos.top){
					$(this).animate({"top":__this.outerHeight()-__h+boxPos.top},250);
				}
			});
		});
		$(this).parents(".grid").css("z-index","50");
	},
	function() {
		$(this).css("background-image","url(/artist/images_en/btn_song_list.png)");
		var __this=$(this).parents(".grid");
		var __h=__this.outerHeight();
		var __l=__this.position().left;
		var __t=__this.position().top;
		$(this).prev().slideToggle('',function(){
			$(".grid").each(function(){
				var boxPos=$(this).position();
				if(__l==boxPos.left&&__t<boxPos.top){
					$(this).animate({"top":__this.outerHeight()-__h+boxPos.top},750);
				}
			});
		});
		$(this).parents(".grid").css("z-index","1");
	});
	
	
	$(".more_txt").toggle(
	function() {
		$(this).prev().slideToggle();
		$(this).find(".close_more").css("display","block");
		$(this).find(".open_more").css("display","none")
	},
	function() {
		$(this).prev().slideToggle();
		$(this).find(".close_more").css("display","none");
		$(this).find(".open_more").css("display","block")
	});
	
	/*
	$(".btn_getmusic").toggle(
	function() {
		$(this).next().slideToggle();
		$(this).parents(".grid").css("z-index","50");
	},
	function() {
		$(this).next().slideToggle();
		$(this).parents(".grid").css("z-index","1");
	});

	$(".btn_getmusic").attr('href','javascript:void(0)');
	$(".btn_getmusic").click(
		function(){
			var t=$(this);
			t.parents(".grid").css("z-index","50");
			var n=t.next().clone();
			var c=t.append(n);
			t.find('.getmusic').slideToggle();
		}
	);

	$(".btn_getmusic").hover(
		function(){
			var t=$(this);
			$(this).find('.getmusic').hide();
			t.parents(".grid").css("z-index","10");
		}
	);
	
		*/
	/*$(".with_dd").hover(
	function() {
		$(this).next().show();
		$(this).parents(".grid").css("z-index","100");
	});

	$("body").click(
	function() {
		$(".with_dd").next().hide();
		$(this).parents(".grid").css("z-index","1");
	});*/
	
	$(".main_navi_d").hover(
		function(){
			var t=$(this);
			t.parents("#main_contents").css("z-index","150");
		}
	);

	
	$(".btn_getmusic").hover(
		function(){
			var t=$(this);
			t.parents(".btnArea").css("z-index","100");
		}
	);
	
});

$(document).ready(function(){
  $(document).bind("contextmenu",function(e){
    return false;
  });
});


/*
	Class:    	dwIMageProtector
	Author:   	David Walsh
	Website:    http://davidwalsh.name
	Version:  	1.0.0
	Date:     	08/09/2008
	Built For:  jQuery 1.2.6
*/

jQuery.fn.protectImage = function(settings) {
	settings = jQuery.extend({
		image: 'blank.gif',
		zIndex: 2000
	}, settings);
	return this.each(function() {
		var position = $(this).position();
		var height = $(this).height();
		var width = $(this).width();
		$('<img />').attr({
			width: width,
			height: height,
			src: settings.image
		}).css({
			border: '1px solid #f00',
			top: position.top,
			left: position.left,
			position: 'absolute',
			zIndex: settings.zIndex
		}).appendTo('body')
	});
};
